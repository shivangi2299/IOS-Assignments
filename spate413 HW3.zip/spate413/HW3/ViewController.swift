//
//  ViewController.swift
//  HW3
//
//  Created by Rohan Panchal on 1/22/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var calculatorWorkings : UILabel!
    
    @IBOutlet var Result : UILabel!
    
    var workings : String = ""
    var prevResult: Double = 0.0
    var prevResultWorkings : String = ""
    var prev : Double = 0.0
    var resultString : String = ""
    var prevresult : Double = 0.0
    override func viewDidLoad() {
        
        super.viewDidLoad()
        clearAll()
        // Do any additional setup after loading the view.
    }

    func clearAll(){
        workings = ""
        calculatorWorkings.text = ""
        Result.text = "0"
        prev = 0.0
       
        calculatorWorkings.accessibilityIdentifier = "CalculatorWorkingsLabel"
                Result.accessibilityIdentifier = "Result"
    }
    

    @IBAction func allclearTap(_ sender: Any) {
        clearAll()
    
    }
    func additiontoWorkings(value : String){
        
            workings = workings + value
            Result.text = workings
            
    }
    
    @IBAction func addTap(_ sender: Any) {
        additiontoWorkings(value: "+")
    }
    func updateResultLabel() {
            calculatorWorkings.text = workings
            
            if !workings.isEmpty {
                let exp = NSExpression(format: workings)
                if let result = exp.expressionValue(with: nil, context: nil) as? Double {
                    if result == prevResult {
                        if let lastCharacter = workings.last, let lastDigit = Double(String(lastCharacter)) {
                            prev += lastDigit
                        }
                    } else {
                        prev = result
                        prevResult = result
                    }
                    resultString = formatResults(result: prev)
                    Result.text = resultString
                }
            }
        }

   
  
    @IBAction func equalsTap(_ sender: Any) {
        if workings.first == "+"  {
            workings.removeFirst()
            
        } else if workings.last == "+" {
            workings.removeLast()
        }
      
         updateResultLabel()
        
      
    }
    
    
    func formatResults(result: Double) -> String {
        if(result.truncatingRemainder(dividingBy: 1) == 0)
        {
            return String(format: "%.0f", result)
        }
        else
        {
            return String(format: "%.2f", result)
        }
    }
    @IBAction func decimalTap(_ sender: Any) {
        additiontoWorkings(value: ".")
    }
    
    @IBAction func zeroTap(_ sender: Any) {
        
        additiontoWorkings(value: "0")
        
    }
    
    @IBAction func oneTap(_ sender: Any) {
        additiontoWorkings(value: "1")
    }
    
    @IBAction func twoTap(_ sender: Any) {
        additiontoWorkings(value: "2")
    }
    @IBAction func threeTap(_ sender: Any) {
        additiontoWorkings(value: "3")
    }
    
    @IBAction func fourTap(_ sender: Any) {
        additiontoWorkings(value: "4")
    }
    
    @IBAction func fiveTap(_ sender: Any) {
        additiontoWorkings(value: "5")
    }
    
    @IBAction func sixTap(_ sender: Any) {
        additiontoWorkings(value: "6")
    }
    @IBAction func sevenTap(_ sender: Any) {
        additiontoWorkings(value: "7")
    }
    @IBAction func eightTap(_ sender: Any) {
        additiontoWorkings(value: "8")
    }
    
    @IBAction func nineTap(_ sender: Any) {
        additiontoWorkings(value: "9")
    }
}

